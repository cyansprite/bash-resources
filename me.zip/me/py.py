#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

class TempCache():
    def __init__(self):
        self.userSettings = [];

class TempWin(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="Temp");
        self.set_border_width(3);
        #self.__files();
        #self.__folders();
        self.__notebook();

    def __files(self):
        def add_filters(dialog):
            filter_text = Gtk.FileFilter()
            filter_text.set_name("Text files")
            filter_text.add_mime_type("text/plain")
            dialog.add_filter(filter_text)

            filter_py = Gtk.FileFilter()
            filter_py.set_name("Python files")
            filter_py.add_mime_type("text/x-python")
            dialog.add_filter(filter_py)

            filter_any = Gtk.FileFilter()
            filter_any.set_name("Any files")
            filter_any.add_pattern("*")
            dialog.add_filter(filter_any)

        dialog = Gtk.FileChooserDialog("Please choose a file", self,
            Gtk.FileChooserAction.OPEN,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             Gtk.STOCK_OPEN, Gtk.ResponseType.OK));

        add_filters(dialog);

        response = dialog.run();
        if response == Gtk.ResponseType.OK:
            print("Open clicked");
            print("File selected: " + dialog.get_filename());
        elif response == Gtk.ResponseType.CANCEL:
            print("Cancel clicked");

        dialog.destroy();

    def __folders(self):
        dialog = Gtk.FileChooserDialog("Please choose a folder", self,
            Gtk.FileChooserAction.SELECT_FOLDER,
            (Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
             "Select", Gtk.ResponseType.OK))
        dialog.set_default_size(800, 400)

        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            print("Select clicked")
            print("Folder selected: " + dialog.get_filename())
        elif response == Gtk.ResponseType.CANCEL:
            print("Cancel clicked")

        dialog.destroy()

    def __notebook(self):
        def style():
            style_provider = Gtk.CssProvider()

            with open('style.css', 'rb') as css:
                css_data = css.read()

            style_provider.load_from_data(css_data)

            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), style_provider,     
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

        self.notebook = Gtk.Notebook()
        self.add(self.notebook)
        self.page1 = Gtk.Box()
        self.page1.set_border_width(10)
        self.page1.add(Gtk.Label('Default Page!'))
        self.notebook.append_page(self.page1, Gtk.Label('Plain Title'))
        self.add(self.notebook)

        self.page1 = Gtk.Box()
        self.page1.set_border_width(10)
        self.page1.add(Gtk.Label('Default Page!'))
        self.notebook.append_page(self.page1, Gtk.Label('Plain Title'))

        style();

class Clipboard():
    def __init__(self):
        self.__clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD);
        self.__primary   = Gtk.Clipboard.get(Gdk.SELECTION_PRIMARY);
    
    def paste(self, clip):
        text = clip.wait_for_text();
        print("\n\nWEEEP :: {}\n\n".format(text));

    def copy(self, clip):
        clip.set_text("weeep",-1)

    
if __name__ == '__main__':
    clip = Clipboard();
    win = TempWin();
    win.connect('delete-event', Gtk.main_quit);
    win.show_all();
    Gtk.main();
