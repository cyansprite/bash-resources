/*My first curses*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <curses.h>

int main(void)
{
    WINDOW * mainwin;

    //init curse

    if( (mainwin = initscr()) == NULL ){
        fprintf(stderr, "Error init ncurses!\n");
        exit(EXIT_FAILURE);
    }

    start_color(); // init color

    /* Our message */
    mvaddstr(6,32, "Hello, world!");


    /*  Make sure we are able to do what we want. If
    has_colors() returns FALSE, we cannot use colours.
    COLOR_PAIRS is the maximum number of colour pairs
    we can use. We use 13 in this program, so we check
    to make sure we have enough available.               */

    if( has_colors() && COLOR_PAIRS >= 13 ){
        int n=1;

        /*Init a bunch of color pairs!*/
        init_pair(1, COLOR_RED, COLOR_BLACK);
        init_pair(2, COLOR_GREEN, COLOR_BLACK);
        init_pair(3, COLOR_YELLOW, COLOR_BLACK);
        init_pair(4, COLOR_BLUE, COLOR_BLACK);
        init_pair(5, COLOR_MAGENTA, COLOR_BLACK);
        init_pair(6, COLOR_CYAN, COLOR_BLACK);
        init_pair(7, COLOR_BLUE, COLOR_BLACK);
        init_pair(8, COLOR_WHITE, COLOR_BLACK);
        init_pair(9, COLOR_BLACK, COLOR_GREEN);
        init_pair(10, COLOR_BLUE, COLOR_BLACK);
        init_pair(11, COLOR_RED, COLOR_BLACK);
        init_pair(12, COLOR_RED, COLOR_BLACK);
        init_pair(13, COLOR_RED, COLOR_BLACK);

        while( n <= 13 ){
            color_set(n,NULL);
            mvaddstr(6 + n, 32, " Hello, world! ");
            n++;
        }
    }

    refresh();
    sleep(3);

    /* clean up */
    delwin(mainwin);
    endwin();
    refresh();

    return EXIT_SUCCESS;
}

