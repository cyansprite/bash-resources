/*WINDER*/

#include <stdlib.h>
#include <stdio.h>
#include <curses.h>

int main(void)
{
    WINDOW *mainwin, *childwin;
    int ch;

    //set dimens
    int width = 23, height = 7;
    int rows = 25, cols = 80;
    int x = (cols - width) / 2;
    int y = (rows - height) / 2;

    //init curse

    if( (mainwin = initscr()) == NULL ){
        fprintf(stderr, "Error init ncurses!\n");
        exit(EXIT_FAILURE);
    }

    noecho();
    keypad(mainwin, TRUE);

    //Make our child window and add a border and some text to it
    childwin = subwin(mainwin,height, width, y, x);
    box(childwin, 0, 0);
    mvwaddstr(childwin, 1, 4, "Move the window");
    mvwaddstr(childwin, 2, 2, "With the arrow keys");
    mvwaddstr(childwin, 3, 6, "or Home/End");
    mvwaddstr(childwin, 5, 3, "Press 'q' to quit");

    refresh();

    /*  Loop until user hits 'q' to quit  */

    while ( (ch = getch()) != 'q' ) {

        switch ( ch ) {

            case KEY_UP:
                    --y;
                break;

            case KEY_DOWN:
                    ++y;
                break;

            case KEY_LEFT:
                    --x;
                break;

            case KEY_RIGHT:
                    ++x;
                break;

            case KEY_HOME:
                x = 0;
                y = 0;
                break;

            case KEY_END:
                x = (cols - width);
                y = (rows - height);
                break;

        }
        mvprintw(7, 10, "You pressed: x%x (%d,%d)", ch, x,y );
        mvwin(childwin, y, x);
    }

    /* clean up */
    delwin(childwin);
    delwin(mainwin);
    endwin();
    refresh();

    return EXIT_SUCCESS;
}

